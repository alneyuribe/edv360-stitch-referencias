---
name: Serene Editorial Studio
colors:
  surface: '#FFFFFF'
  surface-dim: '#d7dbd9'
  surface-bright: '#f6faf8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f4f2'
  surface-container: '#ebefed'
  surface-container-high: '#e5e9e7'
  surface-container-highest: '#dfe3e1'
  on-surface: '#181c1c'
  on-surface-variant: '#3e4947'
  inverse-surface: '#2d3130'
  inverse-on-surface: '#eef2f0'
  outline: '#6e7977'
  outline-variant: '#bdc9c6'
  surface-tint: '#006a62'
  primary: '#00625b'
  on-primary: '#ffffff'
  primary-container: '#087d74'
  on-primary-container: '#c7fff7'
  inverse-primary: '#7ad6cb'
  secondary: '#006a61'
  on-secondary: '#ffffff'
  secondary-container: '#86f2e4'
  on-secondary-container: '#006f66'
  tertiary: '#884428'
  on-tertiary: '#ffffff'
  tertiary-container: '#a65b3e'
  on-tertiary-container: '#fff1ed'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#96f3e7'
  primary-fixed-dim: '#7ad6cb'
  on-primary-fixed: '#00201d'
  on-primary-fixed-variant: '#00504a'
  secondary-fixed: '#89f5e7'
  secondary-fixed-dim: '#6bd8cb'
  on-secondary-fixed: '#00201d'
  on-secondary-fixed-variant: '#005049'
  tertiary-fixed: '#ffdbcf'
  tertiary-fixed-dim: '#ffb59a'
  on-tertiary-fixed: '#380d00'
  on-tertiary-fixed-variant: '#74341a'
  background: '#f6faf8'
  on-background: '#181c1c'
  surface-variant: '#dfe3e1'
  canvas: '#F8FAFB'
  app-surface: '#FBFCFC'
  text-primary: '#14232D'
  text-secondary: '#5C6C76'
  text-muted: '#788590'
  border: '#E8ECEE'
  card-border: '#E7EBEE'
  accent-strong: '#087D74'
  accent-foreground: '#066C64'
  accent-soft: '#E6F6F2'
  selection-surface: '#E7F6F2'
  field-surface: '#F5F7F8'
typography:
  headline-lg:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 17px
    fontWeight: '600'
    lineHeight: 24px
  body-editor:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 31.5px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-navigation:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  label-navigation-active:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-button:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-button-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
  label-caption:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  margin: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

# Design System: Estudio EDV 360

**Design system version:** 1.0 — candidato visual Fase 1
**Idioma de interfaz:** español.
**Superficie primaria:** aplicación web de escritorio (1440 × 900).
**Modo predeterminado:** claro (blancos, grises muy sutiles, acentos verde azulado).
**Atmósfera:** serena, editorial, minimalista, contemporánea y enfocada a la concentración, inspirada en las referencias `inicio.png`, `editor.png`, `voces.png`, `visuales.png`.

## Colores (Modo Claro)
- canvas: #F8FAFB
- app-surface: #FBFCFC
- surface: #FFFFFF
- text-primary: #14232D
- text-secondary: #5C6C76
- text-muted: #788590
- border: #E8ECEE
- card-border: #E7EBEE
- accent: #0D9488
- accent-strong: #087D74 (para botones primarios con texto blanco)
- accent-foreground: #066C64
- accent-soft: #E6F6F2 (píldoras de selección, navegación activa)
- selection-surface: #E7F6F2
- field-surface: #F5F7F8

## Tipografía
- Fuente principal: Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif
- Títulos: 26–28px, semi-bold/bold (weight 700), tracking -0.02em
- Subtítulos / secciones: 17–20px, weight 600
- Navegación e interfaz: 14px, weight 500-600
- Texto de lectura en editor: 16–18px, line-height 1.75
- Botones: 13–14px, weight 600

## Componentes y Shell
- Barra superior (Topbar): 72px de alto, fondo blanco puro #FFFFFF, borde inferior tenue #E8ECEE.
  Elementos: Logo EDV 360 (isotipo triángulo/play redondeado verde azulado + texto "EDV 360"), selector de proyecto ("Proyecto activo: Recorridos culturales · DEMO ⌵"), campo de búsqueda ("Buscar en Estudio..."), icono notificaciones, selector de tema (sol), avatar usuario ("EDV").
- Sidebar (Menú lateral izquierdo): 243px de ancho, fondo blanco #FFFFFF, borde derecho #E8ECEE.
  Sección superior: ESPACIO DE TRABAJO
  Ítems invariables:
  1. Inicio
  2. Proyectos
  3. Estudio (activo con fondo menta #E6F6F2 y texto/icono #087D74)
  4. Biblioteca
  5. Revisiones
  6. Entregas
  Al pie: Configuración
- Botones: Primario en #087D74 con esquinas redondeadas (8-10px), texto blanco. Secundario con fondo blanco y borde #E8ECEE.
- Tarjetas: fondo #FFFFFF, borde 1px #E7EBEE, radio 12-14px, sombra sutil casi imperceptible.
