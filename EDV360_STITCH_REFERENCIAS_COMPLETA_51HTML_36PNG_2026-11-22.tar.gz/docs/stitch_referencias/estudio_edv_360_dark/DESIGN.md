---
name: Estudio EDV 360 Dark
colors:
  surface: '#19232E'
  surface-dim: '#121820'
  surface-bright: '#222D38'
  surface-container-lowest: '#0F161E'
  surface-container-low: '#151D26'
  surface-container: '#19232E'
  surface-container-high: '#202B37'
  surface-container-highest: '#273442'
  on-surface: '#F4F6F8'
  on-surface-variant: '#B5C1CB'
  outline: '#33404C'
  outline-variant: '#25323E'
  primary: '#0E8178'
  on-primary: '#FFFFFF'
  primary-container: '#163B37'
  on-primary-container: '#67D9CB'
  secondary: '#67D9CB'
  on-secondary: '#072824'
  secondary-container: '#173D37'
  on-secondary-container: '#B6F8DC'
  tertiary: '#E2B870'
  on-tertiary: '#2C220E'
  tertiary-container: '#3A3328'
  on-tertiary-container: '#F6CE93'
  error: '#F58688'
  on-error: '#3A1416'
  error-container: '#472B36'
  on-error-container: '#FFAFB7'
  background: '#121820'
  on-background: '#F4F6F8'
  inverse-surface: '#dfe3e1'
  inverse-on-surface: '#2c3130'
  surface-tint: '#78d6cc'
  inverse-primary: '#006a63'
  primary-fixed: '#95f3e8'
  primary-fixed-dim: '#78d6cc'
  on-primary-fixed: '#00201d'
  on-primary-fixed-variant: '#00504a'
  secondary-fixed: '#85f5e7'
  secondary-fixed-dim: '#67d9cb'
  on-secondary-fixed: '#00201d'
  on-secondary-fixed-variant: '#005049'
  tertiary-fixed: '#ffdea9'
  tertiary-fixed-dim: '#ebc077'
  on-tertiary-fixed: '#271900'
  on-tertiary-fixed-variant: '#5e4102'
  surface-variant: '#313635'
typography:
  font-family: Inter, system-ui, -apple-system, sans-serif
  display:
    size: 28px
    weight: 700
    line-height: 1.2
  headline:
    size: 24px
    weight: 700
    line-height: 1.25
  title:
    size: 18px
    weight: 650
    line-height: 1.3
  body:
    size: 14px
    weight: 400
    line-height: 1.5
  label:
    size: 12px
    weight: 600
    line-height: 1.4
  display-lg:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 33.6px
  display-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 28.8px
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 30px
  title-md:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '650'
    lineHeight: 23.4px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 21px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16.8px
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 15px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-lg: 1.5rem
  margin: 1rem
  margin-md: 1.5rem
  margin-lg: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

# Design System: Estudio EDV 360 (Modo Oscuro)

Traducción exacta del lenguaje visual de Estudio EDV 360 a modo oscuro con base en DESIGN.md:
- Fondo general `canvas`: `#121820`
- Superficie principal `app-surface`: `#151D26`
- Superficies y tarjetas `surface`: `#19232E`
- Bordes y separadores sutiles `border`: `#33404C`
- Texto principal `text-primary`: `#F4F6F8`
- Texto secundario y etiquetas `text-secondary`: `#B5C1CB`
- Acento luminoso `accent`: `#67D9CB`
- Acento botón principal `accent-strong`: `#0E8178`
- Fondo de selección / activo `accent-soft`: `#163B37`
- Mantiene exactamente la misma estructura, componentes, proporciones y navegación de las cuatro pantallas.